clear, close all;
addpath("data");
load BatMan.mat X;

%./functions är en mapp som innehåller alla externa funktioner
addpath("functions");


ALTERNATIV = ["1", "2", "3", "4", "5"];
while 1
    % Ta input från användaren
    disp("Programmet kan genomföra följande:");
    disp(ALTERNATIV(1) + ": rotation");
    disp(ALTERNATIV(2) + ": spegling kring linje");
    disp(ALTERNATIV(3) + ": skuvning");
    disp(ALTERNATIV(4) + ": skuvning och rotation");
    disp(ALTERNATIV(5) + ": avsluta programmet");
    
    
    % hämta alternativet från användaren, och be den försöka igen om det inte
    % är ett alternativ
    while 1
        mode = input("Välj vad du vill göra: ", "s");
        if ismember(mode, ALTERNATIV)
            disp("")
            break
        else
            disp("Inte ett giltigt alternativ, försök igen!");
        end
    
    end
    
    
    switch mode
        case ALTERNATIV(1)
            theta = input("Ange rotationsvinkel (grader): ");
            R = rotation(theta);
            X = R*X;
    
        case ALTERNATIV(2)
            a = input("Riktingskoefficient för linjen: ");
            b = input("Skärning av y-axeln för linjen: ");
            M = mirror(a, b);
            X = M*X;
    
        case ALTERNATIV(3)
            shear_factor = input("Ange skuvningsfaktor: ");
            S = shear(shear_factor);
            X = S*X;
    
        case ALTERNATIV(4)
            shear_factor = input("Ange skuvningsfaktor: ");
            theta = input("Ange rotationsvinkel (grader): ");
            S = shear(shear_factor);
            R = rotation(theta);
            T = R*S;
            X = T*X;
    
        case ALTERNATIV(5)
            break;
    end
    
    PlotFigure(X);
    disp("---------------------------------")
    disp("")
end