function M = shear(k)
    M = [1, k; 0, 1];
end