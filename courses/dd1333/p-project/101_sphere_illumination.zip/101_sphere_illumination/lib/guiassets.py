import tkinter as tk 

class AutoLabel(tk.Label):

